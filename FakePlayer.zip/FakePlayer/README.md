# FakePlayer (Paper 26.3)

Zeigt Fake-Spieler mit echtem Skin in der Tabliste an.

- `/fakeplayer add <Name>` - Fake-Spieler mit dem Skin des Spielers `<Name>` hinzufuegen
- `/fakeplayer remove <Name>` - entfernen
- `/fakeplayer list` - alle anzeigen

Alias: `/fp`. Permission: `fakeplayer.use` (Standard: OP).
Die Eintraege werden in `plugins/FakePlayer/data.yml` gespeichert und neu beigetretenen Spielern angezeigt.

## Build
Ordner auf GitHub hochladen (Branch `main`): Der Workflow baut die JAR und legt sie unter **Releases** ab.

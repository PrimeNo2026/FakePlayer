package de.fakeplayer;

import com.destroystokyo.paper.profile.ProfileProperty;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.List;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Sendet Tablisten-Pakete per Reflection (Paper laeuft ab 1.20.5 mit Mojang-Mappings,
 * daher sind die Klassennamen zur Laufzeit stabil und kein NMS-Compile noetig).
 */
@SuppressWarnings({"unchecked", "rawtypes"})
public final class TabPackets {

    private final Logger log;
    private final Class<?> updateCls;
    private final Class<?> actionCls;
    private final Class<?> entryCls;
    private final Class<?> removeCls;
    private final Class<?> gameProfileCls;
    private final Constructor<?> updateCtor;
    private final Constructor<?> entryCtor;
    private final Constructor<?> removeCtor;
    private Method sendMethod;

    public TabPackets(Logger log) throws ReflectiveOperationException {
        this.log = log;
        String base = "net.minecraft.network.protocol.game.";
        updateCls = Class.forName(base + "ClientboundPlayerInfoUpdatePacket");
        actionCls = Class.forName(base + "ClientboundPlayerInfoUpdatePacket$Action");
        entryCls = Class.forName(base + "ClientboundPlayerInfoUpdatePacket$Entry");
        removeCls = Class.forName(base + "ClientboundPlayerInfoRemovePacket");
        gameProfileCls = Class.forName("com.mojang.authlib.GameProfile");

        updateCtor = updateCls.getDeclaredConstructor(EnumSet.class, List.class);
        updateCtor.setAccessible(true);

        Constructor<?> best = null;
        for (Constructor<?> c : entryCls.getDeclaredConstructors()) {
            if (best == null || c.getParameterCount() > best.getParameterCount()) {
                best = c;
            }
        }
        entryCtor = best;
        entryCtor.setAccessible(true);

        removeCtor = removeCls.getConstructor(List.class);
    }

    private Object buildGameProfile(FakeEntry e) throws ReflectiveOperationException {
        var profile = Bukkit.createProfile(e.uuid(), e.name());
        if (e.value() != null && !e.value().isEmpty()) {
            profile.setProperty(new ProfileProperty("textures", e.value(), e.signature()));
        }
        Method m = profile.getClass().getMethod("buildGameProfile");
        return m.invoke(profile);
    }

    private Object buildAddPacket(FakeEntry e) throws ReflectiveOperationException {
        Object gp = buildGameProfile(e);

        Class<?>[] types = entryCtor.getParameterTypes();
        Object[] args = new Object[types.length];
        for (int i = 0; i < types.length; i++) {
            Class<?> t = types[i];
            if (t == UUID.class) {
                args[i] = e.uuid();
            } else if (t == gameProfileCls) {
                args[i] = gp;
            } else if (t == boolean.class) {
                args[i] = true;          // listed / showHat
            } else if (t == int.class) {
                args[i] = 0;             // latency / listOrder
            } else if (t.isEnum()) {
                args[i] = Enum.valueOf((Class<Enum>) t, "SURVIVAL"); // GameType
            } else {
                args[i] = null;          // Anzeigename (-> Profilname), Chat-Session
            }
        }
        Object entry = entryCtor.newInstance(args);

        EnumSet actions = EnumSet.noneOf((Class<Enum>) actionCls);
        for (String n : new String[]{"ADD_PLAYER", "UPDATE_GAME_MODE", "UPDATE_LISTED",
                "UPDATE_LATENCY", "UPDATE_DISPLAY_NAME", "UPDATE_HAT", "UPDATE_LIST_ORDER"}) {
            try {
                actions.add(Enum.valueOf((Class<Enum>) actionCls, n));
            } catch (IllegalArgumentException ignored) {
                // Aktion existiert in dieser Version nicht
            }
        }
        return updateCtor.newInstance(actions, List.of(entry));
    }

    private void send(Player player, Object packet) throws ReflectiveOperationException {
        Object handle = player.getClass().getMethod("getHandle").invoke(player);
        Object connection = handle.getClass().getField("connection").get(handle);
        if (sendMethod == null) {
            for (Method m : connection.getClass().getMethods()) {
                if (m.getName().equals("send") && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isAssignableFrom(packetClass(packet))) {
                    sendMethod = m;
                    break;
                }
            }
            if (sendMethod == null) {
                throw new NoSuchMethodException("send(Packet) nicht gefunden");
            }
        }
        sendMethod.invoke(connection, packet);
    }

    private Class<?> packetClass(Object packet) {
        return packet.getClass();
    }

    public void add(Player player, FakeEntry e) {
        try {
            send(player, buildAddPacket(e));
        } catch (Exception ex) {
            log.warning("Konnte Fake-Spieler " + e.name() + " nicht anzeigen: " + ex);
        }
    }

    public void remove(Player player, FakeEntry e) {
        try {
            send(player, removeCtor.newInstance(List.of(e.uuid())));
        } catch (Exception ex) {
            log.warning("Konnte Fake-Spieler " + e.name() + " nicht entfernen: " + ex);
        }
    }
}

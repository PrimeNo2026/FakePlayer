package de.fakeplayer;

import java.util.UUID;

/** Ein Fake-Spieler in der Tabliste (Skin-Daten sind optional). */
public record FakeEntry(String name, UUID uuid, String value, String signature) {
}

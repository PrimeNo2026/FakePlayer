package de.fakeplayer;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

public final class FakePlayerPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{1,16}");

    private final Map<String, FakeEntry> fakes = new LinkedHashMap<>();
    private final Set<String> pending = ConcurrentHashMap.newKeySet();
    private File dataFile;
    private TabPackets packets;

    @Override
    public void onEnable() {
        try {
            packets = new TabPackets(getLogger());
        } catch (ReflectiveOperationException e) {
            getLogger().severe("Tablisten-Pakete nicht verfuegbar (inkompatible Paper-Version?): " + e);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        dataFile = new File(getDataFolder(), "data.yml");
        load();

        var cmd = getCommand("fakeplayer");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info(fakes.size() + " Fake-Spieler geladen.");
    }

    // ---------- Daten ----------

    private void load() {
        fakes.clear();
        if (!dataFile.exists()) {
            return;
        }
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection sec = y.getConfigurationSection("fakes");
        if (sec == null) {
            return;
        }
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            String name = s.getString("name", key);
            UUID uuid;
            try {
                uuid = UUID.fromString(s.getString("uuid", ""));
            } catch (IllegalArgumentException ex) {
                uuid = fakeUuid(name);
            }
            fakes.put(key.toLowerCase(Locale.ROOT),
                    new FakeEntry(name, uuid, s.getString("value"), s.getString("signature")));
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (var e : fakes.entrySet()) {
            String p = "fakes." + e.getKey();
            y.set(p + ".name", e.getValue().name());
            y.set(p + ".uuid", e.getValue().uuid().toString());
            y.set(p + ".value", e.getValue().value());
            y.set(p + ".signature", e.getValue().signature());
        }
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("data.yml konnte nicht gespeichert werden: " + ex);
        }
    }

    private static UUID fakeUuid(String name) {
        return UUID.nameUUIDFromBytes(("FakePlayer:" + name.toLowerCase(Locale.ROOT)).getBytes());
    }

    // ---------- Events ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player p = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) {
                for (FakeEntry e : fakes.values()) {
                    packets.add(p, e);
                }
            }
        }, 10L);
    }

    // ---------- Command ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sender.sendMessage("§eVerwendung: /" + label + " <add|remove|list> [Name]");
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "add" -> {
                if (args.length < 2) {
                    sender.sendMessage("§eVerwendung: /" + label + " add <Name>");
                    return true;
                }
                add(sender, args[1]);
            }
            case "remove" -> {
                if (args.length < 2) {
                    sender.sendMessage("§eVerwendung: /" + label + " remove <Name>");
                    return true;
                }
                remove(sender, args[1]);
            }
            case "list" -> {
                if (fakes.isEmpty()) {
                    sender.sendMessage("§7Keine Fake-Spieler vorhanden.");
                } else {
                    List<String> names = new ArrayList<>();
                    fakes.values().forEach(e -> names.add(e.name()));
                    sender.sendMessage("§aFake-Spieler (" + names.size() + "): §f" + String.join(", ", names));
                }
            }
            default -> sender.sendMessage("§eVerwendung: /" + label + " <add|remove|list> [Name]");
        }
        return true;
    }

    private void add(CommandSender sender, String name) {
        if (!NAME.matcher(name).matches()) {
            sender.sendMessage("§cUngueltiger Name (1-16 Zeichen: Buchstaben, Zahlen, _).");
            return;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (fakes.containsKey(key)) {
            sender.sendMessage("§c" + name + " existiert bereits als Fake-Spieler.");
            return;
        }
        if (!pending.add(key)) {
            sender.sendMessage("§cDer Skin von " + name + " wird gerade geladen.");
            return;
        }
        sender.sendMessage("§7Lade Skin von " + name + " ...");

        Player online = Bukkit.getPlayerExact(name);
        PlayerProfile profile = online != null ? online.getPlayerProfile() : Bukkit.createProfile(name);

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            String value = null;
            String signature = null;
            String realName = name;
            try {
                profile.complete(true);
                if (profile.getName() != null) {
                    realName = profile.getName();
                }
                for (ProfileProperty prop : profile.getProperties()) {
                    if (prop.getName().equals("textures")) {
                        value = prop.getValue();
                        signature = prop.getSignature();
                        break;
                    }
                }
            } catch (Exception ex) {
                getLogger().warning("Skin-Abfrage fehlgeschlagen: " + ex);
            }
            final String fValue = value;
            final String fSig = signature;
            final String fName = realName;
            Bukkit.getScheduler().runTask(this, () -> {
                pending.remove(key);
                FakeEntry entry = new FakeEntry(fName, fakeUuid(fName), fValue, fSig);
                fakes.put(key, entry);
                save();
                for (Player p : Bukkit.getOnlinePlayers()) {
                    packets.add(p, entry);
                }
                if (fValue == null) {
                    sender.sendMessage("§6" + fName + " wurde hinzugefuegt, aber es wurde kein Skin gefunden (Standard-Skin).");
                } else {
                    sender.sendMessage("§a" + fName + " wurde mit Skin zur Tabliste hinzugefuegt.");
                }
            });
        });
    }

    private void remove(CommandSender sender, String name) {
        FakeEntry entry = fakes.remove(name.toLowerCase(Locale.ROOT));
        if (entry == null) {
            sender.sendMessage("§c" + name + " ist kein Fake-Spieler.");
            return;
        }
        save();
        for (Player p : Bukkit.getOnlinePlayers()) {
            packets.remove(p, entry);
        }
        sender.sendMessage("§a" + entry.name() + " wurde aus der Tabliste entfernt.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("add", "remove", "list")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            for (FakeEntry e : fakes.values()) {
                if (e.name().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(e.name());
            }
        }
        return out;
    }
}
